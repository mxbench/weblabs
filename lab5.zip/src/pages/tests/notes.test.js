import React from 'react';
import ReactDOM from 'react-dom';
import Notes from './../Notes'
import Login from "../Login";
import SignUp from "../SignUp";

it("renders without crashing", () => {
    const div = document.createElement("div");
    ReactDOM.render(<Notes></Notes>, div);
    ReactDOM.render(<Login></Login>, div);
    ReactDOM.render(<SignUp></SignUp>, div);
})
