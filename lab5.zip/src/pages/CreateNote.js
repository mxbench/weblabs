import React, {Component} from 'react';

class CreateNote extends Component {
    render() {
        return (
            <div>
                create
            </div>
        );
    }
}

export default CreateNote;