import React, { Component } from "react";
import { Redirect } from 'react-router-dom';
import axios from "axios";

export default class SignUp extends Component {

    constructor() {
        super();
        this.state = {
            error: "",
            redirect: false
        }
    }

    handleSubmit = e => {
        e.preventDefault();

        if (this.password1 == this.password2) {
            axios.post('users', {
                    username: this.username,
                    password: this.password1
            })
                .then(res => {
                        let token = res.data.access_token
                        localStorage.setItem('token', token)
                        console.log(token)
                        this.setState({ redirect: true })
                        window.location.reload()
                    },
                    err => {
                        console.log(err)
                        this.setState({
                            error: "Username is already taken"
                        })
                    })
        } else {
            this.setState({
                error: "Passwords dont match"
            })
        }


    }

    render() {
        return (
            <div className="outer">
                <div className="inner">
                    <form onSubmit={this.handleSubmit}>
                        <h3>Register</h3>

                        <div className="form-group">
                            <label>Name</label>
                            <input type="text" onChange={e => this.username = e.target.value} className="form-control" placeholder="Username" />
                        </div>

                        <div className="form-group">
                            <label>Password</label>
                            <input type="password" onChange={e => this.password1 = e.target.value} className="form-control" placeholder="Enter password" />
                        </div>

                        <div className="form-group">
                            <label>Password</label>
                            <input type="password" onChange={e => this.password2 = e.target.value}  className="form-control" placeholder="Confirm password" />
                        </div>
                        <span style={{color: "red", fontSize: "15px"}}>{this.state.error}</span>
                        <button type="submit" className="btn btn-dark btn-lg btn-block submit-btn">Register</button>
                        <p className="forgot-password text-right">
                            Already registered <a href="/">log in?</a>
                        </p>
                        { this.state.redirect ? (<Redirect push to="/"/>) : null }
                    </form>
                </div>
            </div>
        );
    }
}