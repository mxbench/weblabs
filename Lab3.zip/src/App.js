import React from "react";
import Notes from "./pages/Notes";
import EditNote from "./pages/EditNote";
import CreateNote from "./pages/CreateNote";
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";
import Login from "./pages/Login";
import SignUp from "./pages/SignUp";


export default function BasicExample() {
    return (
        <Router>
            <>
                <nav className="navbar navbar-expand-lg navbar-light fixed-top">
                    <div className="container">
                        <Link className="navbar-title" to={"/"}>Notes</Link>
                        <div className="nav-links" id="navbarTogglerDemo02">
                            {localStorage.getItem('token') ?
                                <div className="navbar-nav ml-auto">
                                    <Link className="nav-link" onClick={() => {
                                        localStorage.setItem('token', '');
                                        window.location.reload();
                                    }}>Log out</Link>
                                </div> :
                                <ul className="navbar-nav ml-auto">
                                    <li className="nav-item">
                                        <Link className="nav-link" to={"/"}>Sign in</Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" to={"/sign-up"}>Sign up</Link>
                                    </li>
                                </ul>
                            }
                        </div>
                    </div>
                </nav>
                <Switch>
                    {localStorage.getItem('token') ?
                        <Route exact path="/" component={Notes}/> :
                        <Route exact path="/" component={Login}/>}
                    <Route exact path="/sign-in" component={Login} />
                    <Route exact path="/sign-up" component={SignUp} />
                </Switch>
            </>
        </Router>
    );
}