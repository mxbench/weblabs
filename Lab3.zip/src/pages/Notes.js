import React, {Component} from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import Modal from 'react-awesome-modal';


class Notes extends Component {



    constructor(props) {
        super(props)

        // this.colors = ["#B2B7F2", "#A9D1F7", "#B4F0A7", "#FFFFBF", "#FFDFBE", "#FFDFBE", "#FFB1B0"]
        this.colors = ["#E3E3FF", "#FFDBDB", "#E2FCE6", "#FCFADE", "#FFEEE2", "#DFF2FD", "#FCFADE", "#E3E3FF", "#E2FCE6", "#DFF2FD"]


        this.state = {
            notes: [],
            visible: false,
            title: '',
            text: '',
            current: -1
        }
    }

    componentDidMount() {
        axios.get('notebook', {
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            }
        })
            .then(res => {
                this.setState({notes: res.data.reverse()})
                console.log(this.state.notes)
            })
    }

    openModal() {
        let id = this.state.current
        if (id >= 0) {
            console.log(id)
            this.setState({
                current: id
            })
        }

        this.setState({
            visible : true
        });
    }

    closeModal() {
        this.setState({
            visible : false,
            current: -1,
            title: '',
            text: ''
        });
    }

    handleTitleChange(e) {
        this.setState({title: e.target.value})
        console.log(this.state.title)
    }

    handleTextChange(e) {
        this.setState({text: e.target.value})
    }

    saveNote() {
        let id = this.state.current
        if (id >= 0) {
            const data = {
                "name": this.state.title,
                "text": this.state.text
            }
            axios.put(`note/${this.state.current}`, data, {
                headers: {
                    'Authorization': 'Bearer ' + localStorage.getItem('token')
                }
            })
                .then(res => {
                    console.log(res)
                })
        }
        else {
            const data = {
                "name": this.state.title,
                "text": this.state.text
            }
            axios.post('notebook', data, {
                headers: {
                    'Authorization': 'Bearer ' + localStorage.getItem('token')
                }
            })
                .then(res => {
                    console.log(res)
                })
        }

        this.closeModal()
        window.location.reload()
    }

    delNote() {
        let id = this.state.current
        if (id >= 0) {
            axios.delete(`note/${this.state.current}`, {
                headers: {
                    'Authorization': 'Bearer ' + localStorage.getItem('token')
                }
            })
                .then(res => {
                    console.log(res)
                })
        }

        this.closeModal()
        window.location.reload()
    }

    render() {
        return (
                <>
                    <header>
                        <h2>Notes</h2>
                    </header>
                    <div className="main">
                        <div className="note-grid">
                            {this.state.notes.map(note => (
                                <div className="card note" style={{background: this.colors[note.id%10]}} onClick={() => {
                                    this.setState({
                                        current: note.id,
                                        title: note.name,
                                        text: note.text
                                    })
                                    this.openModal()
                                }}>
                                    <h1 className="note-title">{note.name}</h1>
                                    <p className="note-text">{note.text}</p>
                                </div>
                            ))}
                        </div>

                        <Modal className="note-form" visible={this.state.visible} width="545" height="545" effect="fadeInUp" onClickAway={() => this.closeModal()}>
                            <div>
                                <div className="card-header" style={{display: 'flex', flexWrap: 'nowrap'}}>
                                    <input value={this.state.title} onChange={this.handleTitleChange.bind(this)} className="textfield" autoComplete="off" id="note-name" placeholder="Title"
                                           maxLength={31}/>
                                    <button onClick={() => this.closeModal()} className="btn-close">
                                    </button>
                                </div>
                                <div className="card-body">
                                    <textarea value={this.state.text} onChange={this.handleTextChange.bind(this)} className="textfield" id="note-text" placeholder="Text" maxLength={404}/>
                                    <div className="form-btn">
                                        <button id="save-button" onClick={() => this.saveNote()}
                                                className="btn btn-outline-primary btn-floating">
                                            <i className="fas fa-check"/>
                                        </button>
                                        <button id="delete-button" onClick={() => this.delNote()}
                                                className="btn btn-outline-danger btn-floating">
                                            <i className="fas fa-trash"/>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </Modal>


                        <a onClick={() => this.openModal()} className="btn add-button">
                            <i className="fas fa-plus" style={{marginTop: 22}}/>
                        </a>

                        {/*<div className="note-form" data-number={-1}>*/}
                        {/*    <div id="note-form" className="card">*/}
                        {/*        <div className="card-header" style={{display: 'flex', flexWrap: 'nowrap'}}>*/}
                        {/*            <input className="textfield" autoComplete="off" id="note-name" placeholder="Title"*/}
                        {/*                   maxLength={31}/>*/}
                        {/*            <button onclick="typeNote()" className="btn-close">*/}
                        {/*            </button>*/}
                        {/*        </div>*/}
                        {/*        <div className="card-body">*/}
                        {/*            <textarea className="textfield" id="note-text" placeholder="Text" maxLength={404}*/}
                        {/*                      defaultValue={""}/>*/}
                        {/*            <div className="form-btn">*/}
                        {/*                <button id="save-button" onclick="postNote()"*/}
                        {/*                        className="btn btn-outline-primary btn-floating">*/}
                        {/*                    <i className="fas fa-check"/>*/}
                        {/*                </button>*/}
                        {/*                <button id="delete-button" onclick="typeNote()"*/}
                        {/*                        className="btn btn-outline-danger btn-floating">*/}
                        {/*                    <i className="fas fa-trash"/>*/}
                        {/*                </button>*/}
                        {/*            </div>*/}
                        {/*        </div>*/}
                        {/*    </div>*/}
                        {/*</div>*/}
                    </div>
                </>
        );
    }
}

export default Notes;