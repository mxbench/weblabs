import React, { Component } from "react";
import axios from "axios";

export default class Login extends Component {

    constructor() {
        super();
        this.state = {
            error: ""
        }
    }

    handleSubmit = e => {
        e.preventDefault();

        axios.get('users', {
            params: {
                "username": this.username,
                "password": this.password
            }
        })
            .then(res => {
                let token = res.data.access_token
                console.log(token)
                localStorage.setItem('token', token)
                window.location.reload()
            },
                err => {
                    console.log(err)
                    this.setState({
                        error: "Invalid username or password"
                    })
                })

    }

    render() {
        return (
            <div className="outer">
                <div className="inner">

                    <form onSubmit={this.handleSubmit}>

                        <h3>Log in</h3>

                        <div className="form-group">
                            <label>Name</label>
                            <input onChange={e => this.username = e.target.value} type="username" className="form-control" placeholder="Username" />
                        </div>

                        <div className="form-group">
                            <label>Password</label>
                            <input onChange={e => this.password = e.target.value} type="password" className="form-control" placeholder="Enter password" />
                        </div>
                        <span style={{color: "red", fontSize: "15px"}}>{this.state.error}</span>
                        <button type="submit" className="btn btn-dark btn-lg btn-block submit-btn">Sign in</button>
                        <p className="forgot-password text-right">
                            Forgot <a href="#">password?</a>
                        </p>
                    </form>
                </div>
            </div>
        );
    }
}