var grid = document.getElementsByClassName("note-grid")[0];
var form = document.getElementsByClassName("note-form")[0];
var formName = document.getElementById("note-name");
var formText = document.getElementById("note-text");
var save = document.getElementById("save-button");
var del = document.getElementById("delete-button");
var colorCounter = 0;
var notes = [];

fetch("http://127.0.0.1:5000/allnotes")
    .then(res => {
        return res.json();
    })
    .then(loaded => {
        notes = Array(loaded)[0]
        console.log(notes)
        let j = 0;
        notes.forEach(note => {
            addNote(note.name, note.text, j)
            j++;
        })
    })


function typeNote(id=-1){
    console.log(id)
    if(form.style.display == "none"){
        if(id >= 0){
            formName.value = notes[id].name;
            formText.value = notes[id].text;
            save.setAttribute("onclick", "putNote(" + notes[id].id + ")");
            del.setAttribute("onclick", "delNote(" + notes[id].id + ")");
        }
        form.style.display = "block";
    }
    else{
        form.style.display = "none"
        formName.value = null;
        formText.value = null;
        form.setAttribute("data-number", id.toString());
    }
}

function addNote(noteName, noteText, j){
    /*var noteName = document.getElementById("note-name").value
    var noteText = document.getElementById("note-text").value*/

    var card = document.createElement("div")
    var title = document.createElement("div")
    var text = document.createElement("div")

    title.innerHTML = noteName;
    text.innerText = noteText;

    card.setAttribute("class", "card note");
    title.setAttribute("class", "h1 note-title");
    text.setAttribute("class", "p note-text");

    card.setAttribute("style", "background-color:" + color());
    card.setAttribute("onclick", "typeNote(id=" + j + ")");
    card.setAttribute("data-number", j);
    card.appendChild(title);
    card.appendChild(text);

    grid.insertAdjacentElement("afterbegin", card);
}

function postNote(){
    var noteName = formName.value
    var noteText = formText.value;
    fetch("http://127.0.0.1:5000/notebook", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2MTkwODA2MzIsIm5iZiI6MTYxOTA4MDYzMiwianRpIjoiNmFkMzNjYjQtN2FiNy00NDdjLWI5NzEtYTM2NjZjOWE1OTJlIiwiZXhwIjoxNjIxMTU0MjMyLCJpZGVudGl0eSI6OCwiZnJlc2giOmZhbHNlLCJ0eXBlIjoiYWNjZXNzIn0.EGd0V30BZffWn3oKWzrbz3T1M0bFiYbj4BMq52m0Ydo'
        },
        body: JSON.stringify({
            "name": noteName,
            "text": noteText
        })
    })
        .then(res => {
            console.log(res);
            location.reload()
        })
}

function delNote(id){
    fetch("http://127.0.0.1:5000/note/" + id, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2MTkwODA2MzIsIm5iZiI6MTYxOTA4MDYzMiwianRpIjoiNmFkMzNjYjQtN2FiNy00NDdjLWI5NzEtYTM2NjZjOWE1OTJlIiwiZXhwIjoxNjIxMTU0MjMyLCJpZGVudGl0eSI6OCwiZnJlc2giOmZhbHNlLCJ0eXBlIjoiYWNjZXNzIn0.EGd0V30BZffWn3oKWzrbz3T1M0bFiYbj4BMq52m0Ydo'
        }
    })
        .then(res => {
            console.log(res);
            location.reload()
        })
}

function putNote(id){
    var noteName = formName.value
    var noteText = formText.value;
    fetch("http://127.0.0.1:5000/note/" + id, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2MTkwODA2MzIsIm5iZiI6MTYxOTA4MDYzMiwianRpIjoiNmFkMzNjYjQtN2FiNy00NDdjLWI5NzEtYTM2NjZjOWE1OTJlIiwiZXhwIjoxNjIxMTU0MjMyLCJpZGVudGl0eSI6OCwiZnJlc2giOmZhbHNlLCJ0eXBlIjoiYWNjZXNzIn0.EGd0V30BZffWn3oKWzrbz3T1M0bFiYbj4BMq52m0Ydo'
        },
        body: JSON.stringify({
            "name": noteName,
            "text": noteText
        })
    })
        .then(res => {
            console.log(res);
            location.reload()
        })
}

function color(){
    var random_color = ["#CBE4F9", "#CDF5F6", "#D7FFED", "#EFF9DA", "#F9EBDF", "#F9D8D6", "#D6CDEA", "#F2BCDB", "#F7D2DF", "#E0F7F3"]
    var alt_random_color = ["#F2BCDB", "#F7D2DF", "#E0F7F3", "#B2F7F0", "#79E5F2", "#7E92FB"]
    if(colorCounter > random_color.length - 1){
        colorCounter = 0;
    }
    return random_color[colorCounter++]
}