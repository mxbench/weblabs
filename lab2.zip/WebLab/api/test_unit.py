import pytest
from flask_restful import Api, Resource, reqparse, abort, fields, marshal_with
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import JWTManager, jwt_required, get_jwt_identity

from api import app, db


def url_for(path):
    return f"http://127.0.0.1:5000/{path}"


def get_auth_token(*creds):
    res = app.test_client().get(url_for('users'), json={"username": creds[0], "password": creds[1]})
    token = res.json["access_token"]
    return f"Bearer {token}"


@pytest.fixture(scope='module')
def test_client():
    db.drop_all()
    db.create_all()
    with app.test_client() as testing_client:
        with app.app_context():
            yield testing_client


def test_create_user_with_fixture(test_client):
    response = test_client.post(url_for('users'), json={"username": "user1", "password": "1234"})
    assert response.status == '201 CREATED'


def test_auth_user_with_fixture(test_client):
    response = test_client.get(url_for('users'), json={"username": "user1", "password": "1234"})
    assert response.status == "200 OK"


def test_inval_auth_user_with_fixture(test_client):
    response = test_client.get(url_for('users'), json={"username": "user1", "password": "wrong_one"})
    assert response.status == "404 NOT FOUND"


def test_create_note_with_fixture(test_client):
    token = get_auth_token("user1", "1234")
    response = test_client.post(url_for("notebook"), json={"name": "test", "text": "test"}, headers={"Authorization": token})
    assert response.status == '201 CREATED'


def test_owner_get_note_with_fixture(test_client):
    token = get_auth_token("user1", "1234")
    note = test_client.get(url_for("note/1"), headers={"Authorization": token})

    assert note.status == '200 OK'
    assert note.json['name'] == 'test'
    assert note.json['text'] == 'test'
    assert note.json['editors'] == [1]  # owner autofill


def test_owner_edit_note_name_with_fixture(test_client):
    token = get_auth_token("user1", "1234")
    response = test_client.put(url_for("note/1"), json={"name": "edited"}, headers={"Authorization": token})
    note = test_client.get(url_for("note/1"), headers={"Authorization": token})

    assert response.status == '200 OK'
    assert note.json['name'] == 'edited'


def test_owner_edit_note_text_with_fixture(test_client):
    token = get_auth_token("user1", "1234")
    response = test_client.put(url_for("note/1"), json={"text": "edited"}, headers={"Authorization": token})
    note = test_client.get(url_for("note/1"), headers={"Authorization": token})

    assert response.status == '200 OK'
    assert note.json['text'] == 'edited'


def test_owner_edit_note_editors_with_fixture(test_client):
    user2 = test_client.post(url_for('users'), json={"username": "user2", "password": "2222"})
    user3 = test_client.post(url_for('users'), json={"username": "user3", "password": "3333"})
    user4 = test_client.post(url_for('users'), json={"username": "user4", "password": "4444"})
    user5 = test_client.post(url_for('users'), json={"username": "user5", "password": "5555"})
    user6 = test_client.post(url_for('users'), json={"username": "user6", "password": "6666"})

    token = get_auth_token("user1", "1234")

    response = test_client.put(url_for("note/1"), json={"editors": [2,3,4,5,6]}, headers={"Authorization": token})
    note = test_client.get(url_for("note/1"), headers={"Authorization": token})

    assert response.status == '200 OK'
    assert user2.status == '201 CREATED'
    assert user3.status == '201 CREATED'
    assert user4.status == '201 CREATED'
    assert user5.status == '201 CREATED'
    assert user6.status == '201 CREATED'
    assert note.json['editors'] == [2,3,4,5,6,1]


def test_create_note_with_inval_param_fixture(test_client):
    token = get_auth_token("user1", "1234")
    response = test_client.post(url_for("notebook"), json={"name": "test"}, headers={"Authorization": token})
    assert response.status == '400 BAD REQUEST'


def test_create_note_with_inval_text_fixture(test_client):
    token = get_auth_token("user1", "1234")
    response = test_client.post(url_for("notebook"), json={"name": "test", "text": 'a'*500}, headers={"Authorization": token})
    assert response.status == '403 FORBIDDEN'


def test_create_note_with_too_many_editors_fixture(test_client):
    user7 = test_client.post(url_for('users'), json={"username": "user7", "password": "7777"})

    token = get_auth_token("user1", "1234")
    response = test_client.post(url_for("notebook"), json={"name": "test", "text": 'test', "editors": [2,3,4,5,6,7]}, headers={"Authorization": token})

    assert user7.status == '201 CREATED'
    assert response.status == '403 FORBIDDEN'


def test_create_note_with_nonexistent_editors_fixture(test_client):
    token = get_auth_token("user1", "1234")
    response = test_client.post(url_for("notebook"), json={"name": "test", "text": 'test', "editors": [2,3,4,5,42]}, headers={"Authorization": token})

    assert response.status == '404 NOT FOUND'


def test_get_nonexistent_note_with_fixture(test_client):
    token = get_auth_token("user1", "1234")
    note = test_client.get(url_for("note/2"), headers={"Authorization": token})

    assert note.status == '404 NOT FOUND'


def test_edit_nonexistent_note_name_with_fixture(test_client):
    token = get_auth_token("user1", "1234")
    response = test_client.put(url_for("note/2"), json={"name": "edited"}, headers={"Authorization": token})

    assert response.status == '404 NOT FOUND'


def test_delete_nonexistent_note_with_fixture(test_client):
    token = get_auth_token("user1", "1234")
    note = test_client.delete(url_for("note/2"), headers={"Authorization": token})

    assert note.status == '404 NOT FOUND'


def test_editor_get_note_with_fixture(test_client):
    token = get_auth_token("user3", "3333")
    note = test_client.get(url_for("note/1"), headers={"Authorization": token})

    assert note.status == '200 OK'
    assert note.json['name'] == 'edited'
    assert note.json['text'] == 'edited'
    assert note.json['editors'] == [2,3,4,5,6,1]


def test_editor_edit_note_with_fixture(test_client):
    token = get_auth_token("user4", "4444")
    note = test_client.put(url_for("note/1"), json={"name": "edited by 4", "text": 'edited by 4'}, headers={"Authorization": token})

    assert note.status == '200 OK'
    assert note.json['name'] == 'edited by 4'
    assert note.json['text'] == 'edited by 4'


def test_editor_delete_note_fail_with_fixture(test_client):
    token = get_auth_token("user4", "4444")
    note = test_client.delete(url_for("note/1"), headers={"Authorization": token})

    assert note.status == '403 FORBIDDEN'


def test_owner_get_all_notes_with_fixture(test_client):
    token = get_auth_token("user1", "1234")
    notebook = test_client.get(url_for("notebook"), headers={"Authorization": token})

    assert notebook.status == '200 OK'
    assert notebook.json[0]['id'] == 1


def test_owner_delete_note_success_with_fixture(test_client):
    token = get_auth_token("user1", "1234")
    response = test_client.delete(url_for("note/1"), headers={"Authorization": token})
    note = test_client.get(url_for("note/1"), headers={"Authorization": token})

    assert response.status == '200 OK'
    assert note.status == '404 NOT FOUND'


def test_get_all_users_with_fixture(test_client):
    user_list = test_client.get(url_for("allusers"))

    assert user_list.status == '200 OK'


def test_get_all_notes_with_fixture(test_client):
    user_list = test_client.get(url_for("allnotes"))

    assert user_list.status == '200 OK'



